# from project.trip import Trip
# from unittest import TestCase, main
#
#
# class TripTest(TestCase):
#
#     def test_01_init(self):
#         trip = Trip(1000.0, 2, True)
#         self.assertEqual(1000, trip.budget)
#         self.assertEqual(2, trip.travelers)
#         self.assertEqual(True, trip.is_family)
#         self.assertEqual(trip.booked_destinations_paid_amounts, {})
#
#     def test_02_travelers_less_than_1_raises(self):
#
#         with self.assertRaises(ValueError) as ve:
#             trip = Trip(1000.0, 0, False)
#
#         expected_message = 'At least one traveler is required!'
#         output = str(ve.exception)
#         self.assertEqual(expected_message, output)
#
#     def test_03_negative_travelers_raises(self):
#         with self.assertRaises(ValueError) as ve:
#             trip = Trip(1000.0, -1, False)
#
#         expected_message = 'At least one traveler is required!'
#         output = str(ve.exception)
#         self.assertEqual(expected_message, output)
#
#     def test_04_is_family__True_set_to_False(self):
#         trip = Trip(1000.0, 1, True)
#         self.assertEqual(1000, trip.budget)
#         self.assertEqual(1, trip.travelers)
#         self.assertFalse(trip.is_family)
#         self.assertEqual(trip.booked_destinations_paid_amounts, {})
#
#     def test_05_travelers_setter_with_1_traveler(self):
#         trip = Trip(1000.0, 1, False)
#         self.assertEqual(1, trip.travelers)
#
#     def test_06_travelers_setter_with_2_travelers(self):
#         trip = Trip(1000.0, 2, True)
#         self.assertEqual(2, trip.travelers)
#
#     def test_07_is_family_false(self):
#         trip = Trip(1000.0, 1, False)
#         self.assertFalse(trip.is_family)
#
#     def test_08_is_family_true(self):
#         trip = Trip(1000.0, 2, True)
#         self.assertTrue(trip.is_family)
#
#     def test_09_book_trip_not_valid_destination_return_message(self):
#         trip = Trip(1000.0, 2, True)
#         res = trip.book_a_trip("Makedoniq")
#         expected_message = 'This destination is not in our offers, please choose a new one!'
#         self.assertEqual(res, expected_message)
#
#     def test_10_book_trip_with_not_enough_budget_return_message(self):
#         trip = Trip(1000.0, 2, True)
#         res = trip.book_a_trip("Australia")
#         expected_message = 'Your budget is not enough!'
#         self.assertEqual(res, expected_message)
#
#     def test_11_book_trip_required_price_and_budget_is_family_false(self):
#         trip = Trip(1000.0, 2, False)
#         res = trip.book_a_trip("Bulgaria")
#         expected_message = 'Successfully booked destination Bulgaria! Your budget left is 0.00'
#         self.assertEqual(res, expected_message)
#         self.assertEqual(trip.booked_destinations_paid_amounts, {"Bulgaria": 1000.0})
#
#     def test_12_book_trip_required_price_and_budget_is_family_true(self):
#         trip = Trip(1000.0, 2, True)
#         res = trip.book_a_trip("Bulgaria")
#         expected_message = 'Successfully booked destination Bulgaria! Your budget left is 100.00'
#         self.assertEqual(res, expected_message)
#         self.assertEqual(trip.booked_destinations_paid_amounts, {"Bulgaria": 900.0})
#
#     def test_13_booking_status_with_no_paid_amounts(self):
#         trip = Trip(1000.0, 2, True)
#         res = trip.booking_status()
#         expected_message = f'No bookings yet. Budget: 1000.00'
#         self.assertEqual(res, expected_message)
#
#     def test_14_booking_status_with_paid_amounts(self):
#         trip = Trip(30000.0, 2, True)
#         trip.book_a_trip("Bulgaria")
#         trip.book_a_trip("New Zealand")
#
#         self.assertEqual(trip.booked_destinations_paid_amounts, {"Bulgaria": 900.0, "New Zealand": 13500.0})
#         res = trip.booking_status()
#         output = "Booked Destination: Bulgaria\nPaid Amount: 900.00\n" \
#               "Booked Destination: New Zealand\nPaid Amount: 13500.00\n" \
#               "Number of Travelers: 2\nBudget Left: 15600.00"
#         self.assertEqual(res, output)
#
#
# if __name__ == "__main__":
#     main()
