from project.task import Task


class Section:
    def __init__(self, name: str):
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        if new_task in self.tasks:
            return f"Task is already in the section {self.name}"
        self.tasks.append(new_task)
        return f"Task {new_task.details()} is added to the section"

    def complete_task(self, task_name: str):
        searched_task = self._find_completed_task(task_name)
        if searched_task is not None:
            searched_task.completed = True
            return f"Completed task {task_name}"
        return f"Could not find task with the name {task_name}"

    def clean_section(self):
        completed_tasks = [t for t in self.tasks if t.completed]
        self.tasks = [t for t in self.tasks if not t.completed]
        return f"Cleared {len(completed_tasks)} tasks."

    def view_section(self):
        task_details = '\n'.join(t.details() for t in self.tasks)
        result = f"Section {self.name}:\n{task_details}\n"
        return result

    ###
    def _find_completed_task(self, tsk_name):
        searched_task = next((t for t in self.tasks if t.name == tsk_name), None)
        return searched_task


# task = Task("Make bed", "27/05/2020")
# print(task.change_name("Go to University"))
# print(task.change_due_date("28.05.2020"))
# task.add_comment("Don't forget laptop")
# print(task.edit_comment(0, "Don't forget laptop and notebook"))
# print(task.details())
# section = Section("Daily tasks")
# print(section.add_task(task))
# second_task = Task("Make bed", "27/05/2020")
# section.add_task(second_task)
# print(section.clean_section())
# print(section.view_section())




# from project.task import Task
#
#
# class Section:
#     def __init__(self, name: str):
#         self.name = name
#         self.tasks = []
#
#     def add_task(self, new_task: Task):
#         if new_task in self.tasks:
#             return f"Task is already in the section {self.name}"
#         self.tasks.append(new_task)
#         return f"Task {new_task.details()} is added to the section"
#
#     def complete_task(self, task_name: str):
#         for t in self.tasks:
#             if t.name == task_name:
#                 t.completed = True
#                 return f"Completed task {task_name}"
#         return f"Could not find task with the name {task_name}"
#
#     def clean_section(self):
#         completed_tasks = [t for t in self.tasks if t.completed]
#         self.tasks = [t for t in self.tasks if not t.completed]
#         return f"Cleared {len(completed_tasks)} tasks."
#
#     def view_section(self):
#         result = f"Section {self.name}:\n"
#         for t in self.tasks:
#             result += f"{t.details()}\n"
#         return result





####################               TEST ##################
# from project.task import Task
# from project.section import Section
#
#
# import unittest
# class Test(unittest.TestCase):
#
#     def test_task_init(self):
#         task = Task("Tst", "27.04.2020")
#         message = f"{task.name} - {task.due_date}"
#         expected = "Tst - 27.04.2020"
#         self.assertEqual(message, expected)
#
#     def test_change_name_working(self):
#         task = Task("Tst", "27.04.2020")
#         task.change_name("New name")
#         message = task.name
#         expected = "New name"
#         self.assertEqual(message, expected)
#
#     def test_change_name_same_name(self):
#         task = Task("Tst", "27.04.2020")
#         message = task.change_name("Tst")
#         expected = "Name cannot be the same."
#         self.assertEqual(message, expected)
#
#     def test_change_due_date_working(self):
#         task = Task("Tst", "27.04.2020")
#         task.change_due_date("21.05.2020")
#         message = task.due_date
#         expected = "21.05.2020"
#         self.assertEqual(message, expected)
#
#     def test_edit_comment_working(self):
#         task = Task("Tst", "27.04.2020")
#         task.add_comment("pay the bills")
#         message = task.edit_comment(0, "finish my homework")
#         expected = "finish my homework"
#         self.assertEqual(message, expected)
#
#     def test_edit_comment_not_found(self):
#         task = Task("Tst", "27.04.2020")
#         task.add_comment("pay the bills")
#         message = task.edit_comment(1, "finish my homework")
#         expected = "Cannot find comment."
#         self.assertEqual(message, expected)
#
#     def test_section_init(self):
#         section = Section("New section")
#         message = f"{section.name} - {len(section.tasks)}"
#         expected = "New section - 0"
#         self.assertEqual(message, expected)
#
#     def test_add_task(self):
#         section = Section("New section")
#         task = Task("Tst", "27.04.2020")
#         message = section.add_task(task)
#         expected = "Task Name: Tst - Due Date: 27.04.2020 is added to the section"
#         self.assertEqual(message, expected)
#
#     def test_add_task_already_added(self):
#         section = Section("New section")
#         task = Task("Tst", "27.04.2020")
#         section.add_task(task)
#         message = section.add_task(task)
#         expected = "Task is already in the section New section"
#         self.assertEqual(message, expected)
#
#     def test_complete_task(self):
#         section = Section("New section")
#         task = Task("Tst", "27.04.2020")
#         section.add_task(task)
#         section.complete_task("Tst")
#         message = task.completed
#         self.assertTrue(message)
#
#     def test_complete_task_message(self):
#         section = Section("New section")
#         task = Task("Tst", "27.04.2020")
#         section.add_task(task)
#         message = section.complete_task("Tst")
#         expected = "Completed task Tst"
#         self.assertEqual(message, expected)
#
#     def test_complete_not_found(self):
#         section = Section("New section")
#         message = section.complete_task("Tst")
#         expected = "Could not find task with the name Tst"
#         self.assertEqual(message, expected)
#
#     def test_clean_section(self):
#         section = Section("New section")
#         task = Task("Tst", "27.04.2020")
#         section.add_task(task)
#         section.complete_task("Tst")
#         message = section.clean_section()
#         expected = "Cleared 1 tasks."
#         self.assertEqual(message, expected)
#
#     def test_view_section(self):
#         section = Section("New section")
#         message = section.view_section().strip()
#         expected = "Section New section:"
#         self.assertEqual(message, expected)
# if __name__ == '__main__':
#     unittest.main()
#
#

